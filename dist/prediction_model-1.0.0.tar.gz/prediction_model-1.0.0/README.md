|- Manifest.in
|-- prediction_model